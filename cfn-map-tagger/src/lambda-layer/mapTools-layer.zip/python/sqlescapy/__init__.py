from .sqlescape import sqlescape
name = "sqlescape"
